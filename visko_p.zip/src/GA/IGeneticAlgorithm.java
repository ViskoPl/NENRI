package GeneticAlgorithm;

public interface IGeneticAlgorithm {
}
