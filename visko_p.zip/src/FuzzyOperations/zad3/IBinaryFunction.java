package zad3;

import zad2.IFuzzySet;

public interface IBinaryFunction {
  public double valueAt(double x, double y);
}