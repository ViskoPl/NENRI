package zad3;

public interface IUnaryFunction {
  public double valueAt(double x);
}