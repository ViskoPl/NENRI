package zad2;

public interface IIntUnaryFunction {
  public double valueAt(int x);
}