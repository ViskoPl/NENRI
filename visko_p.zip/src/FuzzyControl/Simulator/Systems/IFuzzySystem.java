package Simulator.Systems;

import zad2.IFuzzySet;

public interface IFuzzySystem {
    double conclude(int L, int D, int DK, int LK, int V, int S);
}
