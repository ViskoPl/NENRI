package Simulator.Decoders;

import zad2.IFuzzySet;

public interface IDecoder {
    double decode(IFuzzySet set);
}
