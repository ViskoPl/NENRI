package Simulator.Rules;

import zad2.IFuzzySet;

public interface IRule {
    public double calculate(int L, int D, int LK, int DK, int V, int S);
}
