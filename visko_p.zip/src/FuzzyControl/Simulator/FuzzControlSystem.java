package Simulator;

public class FuzzControlSystem {
}
