package lab5.layers;

// np.java -> https://gist.github.com/Jeraldy/7d4262db0536d27906b1e397662512bc

public interface ILayer {

}
