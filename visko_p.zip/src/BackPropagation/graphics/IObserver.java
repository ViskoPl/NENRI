package lab5.graphics;

public interface IObserver {
     void update();
}
