package lab5.algorithms;

import lab5.layers.ILayer;

import java.util.List;

public class StohasticBackPropagationAlgorithm implements IAlgorithm{
    @Override
    public void train(List<ILayer> layers, double learning_rate) {

    }
}
