package ga;

public interface IGeneticAlgorithm {
}
