package zad4;

import zad1.Domain;
import zad1.DomainElement;
import zad1.IDomain;
import zad2.IFuzzySet;
import zad2.MutableFuzzySet;

public class Main2 {
    public static void main(String[] args) {
        IDomain u1 = Domain.intRange(1, 5); // {1,2,3,4}
        IDomain u2 = Domain.intRange(1, 4);
        IDomain u3 = Domain.intRange(1, 5); // {1,2,3,4}

        IFuzzySet r1 = new MutableFuzzySet(Domain.combine(u1, u2)) .set(DomainElement.of(1,1), 0.3) .set(DomainElement.of(1,2), 1) .set(DomainElement.of(3,3), 0.5) .set(DomainElement.of(4,3), 0.5);
        IFuzzySet r2 = new MutableFuzzySet(Domain.combine(u2, u3)) .set(DomainElement.of(1,1), 1) .set(DomainElement.of(2,1), 0.5) .set(DomainElement.of(2,2), 0.7) .set(DomainElement.of(3,3), 1) .set(DomainElement.of(3,4), 0.4);
        IFuzzySet r1r2 = Relations.compositionOfBinaryRelations(r1, r2);
    }

}
